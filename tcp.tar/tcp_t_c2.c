#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#define NUM 32
#include "mymsg.h"

char me[12];
void * read_thread(void *p){
int comm_sock=*(int*)p;
//char buffer[NUM];
msg mymsg;
int msglen;
msglen=sizeof(msg);
while(1){
memset(&mymsg,'\0',msglen);
read(comm_sock,&mymsg,msglen);
printf("%s send to me throught server:%s\n",mymsg.me,mymsg.mess);
if(strcmp(mymsg.mess,"exit")==0)break;
}
}

//login
void login(int comm_sock){
int msglen;
msg sendmsg;
msglen=sizeof(msg);
memset(&sendmsg,'\0',msglen);
memset(me,'\0',12);
sendmsg.command=1;
//scanf("%d",&sendmsg.command);
//scanf("%s",sendmsg.sendto);
strcpy(sendmsg.sendto,"login");
sendmsg.sendtolen=strlen(sendmsg.sendto);
//scanf("%s",sendmsg.mess);
strcpy(sendmsg.mess,"login");

sendmsg.messlen=strlen(sendmsg.mess);
//scanf("%d",sendmsg.command);
//sendmsg.melen=5;
scanf("%s",me);
strcpy(sendmsg.me,me);
sendmsg.melen=strlen(sendmsg.me);

write(comm_sock,&sendmsg,msglen);
}
int main(){
struct sockaddr_in  ser_addr;
int comm_sock;
int len;
char buffer[NUM];
pthread_t tid;
void *r;
int msglen;
msg sendmsg;
comm_sock=socket(AF_INET,SOCK_STREAM,0);
ser_addr.sin_family=AF_INET;
ser_addr.sin_addr.s_addr=inet_addr("127.0.0.1");
ser_addr.sin_port=9765;
len=sizeof(ser_addr);
//len=sizeof(ser_addr);
//printf();
connect(comm_sock,(struct sockaddr*)&ser_addr,len);
login(comm_sock);
pthread_create(&tid,0,read_thread,(void*)(&comm_sock));
while(1){
//printf("");
msglen=sizeof(msg);
memset(&sendmsg,'\0',msglen);
scanf("%d",&sendmsg.command);
scanf("%s",sendmsg.sendto);
sendmsg.sendtolen=strlen(sendmsg.sendto);
scanf("%s",sendmsg.mess);
sendmsg.messlen=strlen(sendmsg.mess);
//scanf("%d",sendmsg.command);
//sendmsg.melen=5;
strcpy(sendmsg.me,me);
sendmsg.melen=strlen(sendmsg.me);
//strcpy(buffer,"hello server");
write(comm_sock,&sendmsg,msglen);
if(strcmp(sendmsg.mess,"exit")==0)break;
}
//memset(buffer,'\0',NUM);
//read(comm_sock,buffer,NUM-1);
//printf("read from server is :%s\n",buffer);
//exit(0);
pthread_join(tid,&r);
}
