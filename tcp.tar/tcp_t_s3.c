#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <semaphore.h>
#include "mymsg.h"
#define  NUM 32
struct _client_id_fd{
char name[12];
int fd;
char group;
};
sem_t mysem;
struct _client_id_fd  myfd[NUM];
int my_fd_i=0;
int find_pair_fd(char*pair){
int i=0;
sem_wait(&mysem);
printf("my_fd_i:%d\n",my_fd_i);
for(;i<my_fd_i;i++){
printf("%d:%d,pair:%s,name:%s\n",my_fd_i,i,pair,myfd[i].name);
if(strcmp(myfd[i].name,pair)==0){
sem_post(&mysem);
return myfd[i].fd;
 }}
sem_post(&mysem);
return -1;

}
void sendtogroup(msg mymsg){// send to group
int i=0;
char groupid=0;
int msglen;
msglen=sizeof(msg);
//sprintf(mymsg.mess,"%d",groupid);
groupid=mymsg.sendto[0];
sem_wait(&mysem);
printf("my_fd_i:%d\n",my_fd_i);
for(;i<my_fd_i;i++){
printf("%d:%d,group:%d,name:%s\n",my_fd_i,i,myfd[i].group,myfd[i].name);
if(myfd[i].group==groupid){
write(myfd[i].fd,&mymsg,msglen);
//sem_post(&mysem);
//return 1;
 }}
sem_post(&mysem);
return ;

}
//addto group
int addtogroup(msg mymsg){
int i=0;
char groupid;
//sprintf(mymsg.mess,"%d",groupid);
groupid=mymsg.mess[0];
sem_wait(&mysem);
for(;i<my_fd_i;i++){
//printf("%s,pair:%s\n",myfd[i].name,);
if(strcmp(myfd[i].name,mymsg.me)==0){
myfd[i].group=groupid;
sem_post(&mysem);
return i ;
 }}
sem_post(&mysem);
return -1;

}

void * comm_cli_thread(void * p){
//char buf:fer[NUM];
msg mymsg;
int msglen;
int pairfd;
int i;
int comm_sock=*(int*)p;
msglen=sizeof(msg);
while(1){
memset(&mymsg,'\0',msglen);
read(comm_sock,&mymsg,msglen);
printf("read from client is:command:%d,pair:%s,me:%s,mess: %s\n",mymsg.command,mymsg.sendto,mymsg.me,mymsg.mess);
if(strcmp(mymsg.mess,"exit")==0){
write(comm_sock,&mymsg,msglen);
printf("This client exit\n");
//compelte,delete fd and name from myfd,
close(comm_sock);
break;
}
else
{
switch(mymsg.command){
case 1://login
sem_wait(&mysem);//to complete when my_fd_i>=32
strncpy(myfd[my_fd_i].name,mymsg.me,mymsg.melen);
myfd[my_fd_i].fd=comm_sock;
my_fd_i++;
sem_post(&mysem);
for(i=0;i<my_fd_i;i++){
printf("name:%s,fd:%d\n",myfd[i].name,myfd[i].fd);
}
break;
case 2://private chat
pairfd=find_pair_fd(mymsg.sendto);
printf("sendto:%s,fd:%d\n",mymsg.sendto,pairfd);
write(pairfd,&mymsg,msglen);

break;
case 3:
sendtogroup(mymsg);
break;
case 5: //add to group
addtogroup(mymsg);
break;
case 6:
sendtogroup(mymsg);
break;
}
//memset(&mymsg,'\0',msglen);
//strcpy(buffer,"hello client");
}
//write(comm_sock,buffer,strlen(buffer));
}
pthread_exit("ok");
}
int main(){
struct sockaddr_in ser_addr,cli_addr;
int ser_sock,cli_sock;
char buffer[NUM];
int len;
pthread_t tid;
sem_init(&mysem,0,1);
ser_sock=socket(AF_INET,SOCK_STREAM,0);
ser_addr.sin_family=AF_INET;
ser_addr.sin_addr.s_addr=htonl(INADDR_ANY);
ser_addr.sin_port=9765;
len=sizeof(ser_addr);
bind(ser_sock,(struct sockaddr*)&ser_addr,len);
listen(ser_sock,5);
while(1){
printf("waiting for clients' connecting\n");
len=sizeof(cli_addr);
cli_sock=accept(ser_sock,(struct sockaddr*)&cli_addr,&len);
pthread_create(&tid,0,comm_cli_thread,(void*)&cli_sock);
//memset(buffer,'\0',NUM);
//read(cli_sock,buffer,NUM-1);
//printf("read from cli is: %s\n",buffer);
//memset(buffer,'\0',NUM);
//strcpy(buffer,"hello client");
//write(cli_sock,buffer,strlen(buffer));
//close(cli_sock);

}
sem_destroy(&mysem);
exit(0);


}
