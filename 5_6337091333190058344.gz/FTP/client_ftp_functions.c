#include "client_ftp.h"
static size_t size_packet = sizeof(ftp_pack);
#define CMD_LEN 10
void opendataport(ftp_pack* pack, int fd);
typedef struct{
	char cmd_str[CMD_LEN];//cmd str
	enum CMD_ID id;//enum number
}ftp_cmd;			//just for below

static const ftp_cmd commandlist[NCOMMANDS]=
	{
		{"send",SEND},
		{"chat",CHAT},
		{"put",PUT},
		{"bye",BYE},
		{"join",JOIN},
		{"leave",LEAVE},
		{"login",LOGIN}
	};

//
int parse_command(struct packet*pack,char s[LENUSERINPUT])
{
	char* savestate;
	char* token;
	int j;

		token = strtok_r(s, " \t\n", &savestate);
		if(token != NULL)		
		for(j = 0; j < NCOMMANDS; j++)
		{	
			if(!strcmp(token, commandlist[j].cmd_str))
			{
				pack->type=COMMAND;
				pack->comid= commandlist[j].id;
				if(pack->comid==CHAT){
					if(atoi(savestate)==0){
						printf("error command\n");
						return 1;
					}
					curr_to=atoi(savestate);
					printf("sending to %d \n",curr_to);
					strtok_r(NULL, " \t\n", &savestate);
					return 0;
				}else 
				if(pack->comid==JOIN){
					if(atoi(savestate)==0){
						printf("error join\n");
						return 1;
					}
					pack->to=atoi(savestate);
					return 0;
				}else 
				if(pack->comid==LEAVE){
					if(atoi(savestate)==0){
						printf("error leave\n");
						return 1;
					}
					pack->to=atoi(savestate);
					return 0;
				}
				pack->to=curr_to;
				strcpy(pack->data,savestate);
				return 0;
			}
		}
		return -1;
}

void command_bye(ftp_pack* pack, int fd)//will not error basiclly
{
	bzero(pack,size_packet);
	pack->type = COMMAND;
	pack->ver=1;
	pack->comid = BYE;
	if((send(fd, pack, size_packet, 0)) != size_packet)
		err_exit("send err(ls)");
	close(fd);
	exit(0);
}

void command_send(ftp_pack* pack)//will not error basiclly
{
	if((send(fd_control, pack, size_packet, 0)) != size_packet)
		err_exit("send err(send)");
}
void command_leave(ftp_pack* pack)//will not error basiclly
{
	if((send(fd_control, pack, size_packet, 0)) != size_packet)
		err_exit("send err(send)");
}
void command_join(ftp_pack* pack)//will not error basiclly
{
	if((send(fd_control, pack, size_packet, 0)) != size_packet)
		err_exit("send err(send)");
}


void command_put(ftp_pack* pack,  int fd, char* filename)
{
	if(!fd_data)
		opendataport(pack,fd);
	FILE* f = fopen(filename, "rb");
	if(!f)
	{
		fprintf(stderr, "File could not be opened for reading. Aborting...\n");
		return;
	}
	int x;
	pack->type = COMMAND;
	pack->ver=1;
	pack->to=curr_to;
	pack->comid = PUT;
	strcpy(pack->data, filename);
	if((send(fd, pack, size_packet, 0)) != size_packet)
		err_exit("send");
	if((recv(fd, pack, size_packet, 0)) <= 0)
		err_exit("recv");
	cali_pack(pack);
	if(pack->type == MSG && pack->comid == PUT && strlen(pack->data))
	{
		printf("\t%s\n", pack->data);
		pack->type = DATA;
		send_file(pack, fd_data, f);
		fclose(f);
	}
	send_EOT(pack, fd_data);
}

void opendataport(ftp_pack* pack, int fd){//establishing data connection!

	fd_data=create_socket(IPSERVER,DATAPORT);
	if(fd_data>0){
		printf("Connected via data port:%d\n",DATAPORT);
	}else
	{
		err_exit("eerror establishing data connection!");
	}	
}

void * recv_main(void *args)
{
 ftp_pack *pack=malloc(size_packet);
	for(;;){
	if((recv(fd_control, pack, size_packet, 0)) <= 0)
		err_exit("recv err");
	cali_pack(pack);
	//if(pack->comid==SEND&&pack->to==my_id)
	{
		printf("\nRecv From:%d %s->%s\nCLIENT>",pack->from,pack->from_name, pack->data);
		fflush(stdout);
	}
}
 
}
void command_login(ftp_pack* pack, int fd, char* data)
{
	pack->type = COMMAND;
	pack->ver=1;
	pack->comid = LOGIN;
	if((send(fd, pack, size_packet, 0)) != size_packet)
		err_exit("send err");
	if((recv(fd, pack, size_packet, 0)) <= 0)
		err_exit("recv err");
	cali_pack(pack);
	if(pack->type == MSG && pack->comid == LOGIN)
	{
		if(!strcmp(pack->data, "success")){
			printf("\t%s success,your id is %d.\n",pack->data,pack->to);
			my_id=pack->to;
 
 
		pthread_t t_listen;
		pthread_create(&t_listen, NULL, (void *)recv_main,NULL);
}
		else{
			printf(pack->data);
			return;
		}
	}
	else
		fprintf(stderr, "\tError executing command on the server.\n");
}


int create_socket(const char *ip, const int port_number)
{
    struct sockaddr_in server_addr = {0};
    server_addr.sin_family = AF_INET;           /* ipv4 */
    server_addr.sin_port = htons(port_number);
    if(inet_pton(PF_INET, ip, &server_addr.sin_addr) == -1){
        err_exit("inet_pton");
    }
    int sockfd = socket(PF_INET, SOCK_STREAM, 0);
    if(sockfd == -1){
        err_exit("socket");
    }

    if(connect(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1){
        err_exit("connect");
    }

    return sockfd;
}