#include <file_transfer_functions.h>

static size_t size_packet = sizeof(struct packet);

void send_EOT(struct packet* pack,int sfd)
{
	pack->type = EOT;
	if((send(sfd, pack, size_packet, 0)) != size_packet)
		err_exit("send err");
}

void send_TERM(struct packet* pack,int sfd)
{
	pack->type = TERM;
	if((send(sfd, pack, size_packet, 0)) != size_packet)
		err_exit("send err");
}

void send_file(struct packet* pack,int sfd, FILE* f)
{
	int i = 0, j = 0;
	
	while(!feof(f))
	{
		memset(pack->data, '\0', sizeof(char) * LENBUFFER);
		pack->datalen = fread(pack->data, 1, LENBUFFER - 1, f);
		i += pack->datalen;
		if((send(sfd, pack, size_packet, 0)) != size_packet)
			err_exit("send err");
		j++;
	}
	fprintf(stderr, "\t%d byte(s) read.\n", i);
	fprintf(stderr, "\t%d data packet(s) sent.\n", j);
	fflush(stderr);
}

void receive_file(struct packet* pack,int sfd, FILE* f)
{
	int i = 0, j = 0;
	if((recv(sfd, pack, size_packet, 0)) <= 0)
		err_exit("recv err");
	j++;
	cali_pack(pack);
	//printpacket(hp, HP);
	while(pack->type == DATA)
	{
		i += fwrite(pack->data, 1, pack->datalen, f);
		if((recv(sfd, pack, size_packet, 0)) <= 0)
			err_exit("recv err");
		j++;
		cali_pack(pack);
		//printpacket(hp, HP);
	}
	fprintf(stderr, "\t%d data packet(s) received.\n", --j);	// j decremented because the last packet is EOT.
	fprintf(stderr, "\t%d byte(s) written.\n", i);
	if(pack->type == EOT)
		return;
	else
	{
		fprintf(stderr, "Error occured while downloading remote file.\n");
		exit(2);
	}
	fflush(stderr);
}

