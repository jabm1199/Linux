#include "server_ftp.h"
static size_t size_packet = sizeof(struct packet);
void pathcat(client_info* ci,int);
void send_ERR(client_info* ci,char *msg);

void command_login(client_info* ci)//from anony to user
{
	if(ci->perm!=NIL){
		send_ERR(ci,"Reject:you have loged in\n");
		send_EOT(&(ci->buffer), ci->client_fd);
	return;
	}

	char* savestate;
	char* token;
	token = strtok_r(ci->buffer.data, " \t\n", &savestate);
		if(token != NULL)	
	mod_client(ci,token,savestate);
		ci->buffer.type = MSG;
	if(ci->perm!=NIL){
	strcpy(ci->buffer.data, "success");
	ci->buffer.to=ci->client_fd;
	}
	else strcpy(ci->buffer.data, "LOGIN failed...");
	if(( send(ci->client_fd, &ci->buffer, size_packet, 0)) != size_packet)
		close_conn(ci);
}

void command_send(client_info* ci)//from anony to user
{
	int i;
	if(ci->perm==NIL){
		send_ERR(ci,"Reject:you need to log in first\n");
		send_EOT(&(ci->buffer), ci->client_fd);
	return;
	}
	ci->buffer.from=ci->client_fd;
	strcpy(ci->buffer.from_name,ci->name);
	if(ci->buffer.to<50&&ci->buffer.to>0){
	if(( send(ci->buffer.to, &ci->buffer, size_packet, 0)) != size_packet)
		{printf("priv error\n");
		close_conn(ci);}
	}else
	{
		for(i=0;i<50;i++)
		if(grouplist[ci->buffer.to-50].fd_list[i]==1&&i!=ci->client_fd){
			if(( send(i, &ci->buffer, size_packet, 0)) != size_packet)
				{
					//close_conn(ci);
					grouplist[ci->buffer.to-50].fd_list[i]==0;
					
				}


		}
	}
	
}
//join grooup
void command_join(client_info* ci)//from anony to user
{//printf("in join\n");
	if(ci->perm==NIL){
		send_ERR(ci,"Reject:you need to log in first\n");
		send_EOT(&(ci->buffer), ci->client_fd);
	return;
	}
	printf("%d\n",ci->buffer.to);
	if(ci->buffer.to>=50&&ci->buffer.to<100){
	if(grouplist[ci->buffer.to-50].fd_list[ci->client_fd]==0)
		grouplist[ci->buffer.to-50].fd_list[ci->client_fd]=1;
		else send_ERR(ci,"you already in");
	}else send_ERR(ci,"g num error");

		
	printf("%d join %d\n",ci->client_fd,ci->buffer.to);
}

//leave group
void command_leave(client_info* ci)//from anony to user
{
	if(ci->perm==NIL){
		send_ERR(ci,"Reject:you need to log in first\n");
		send_EOT(&(ci->buffer), ci->client_fd);
	return;
	}
	if(ci->buffer.to>=50&&ci->buffer.to<100){
	if(grouplist[ci->buffer.to-50].fd_list[ci->client_fd]==1)
	grouplist[ci->buffer.to-50].fd_list[ci->client_fd]=0;
	else send_ERR(ci,"you are not in");
	}else
	{
		send_ERR(ci,"g num error");
	}
	
	printf("%d leave %d\n",ci->client_fd,ci->buffer.to);
}

void mod_client(client_info *ci,char username[],char passwd[]){//fill the passwd ,wd,validate its identidy//#BUG
	int i;
	
	ci->perm=NIL;
	if(!username||!passwd){
		strcpy(ci->name,"Anonymous");
	}else
	for(i=0;i<user_num;i++)
	{
		if (!strcmp(userlist[i]->name,username)&&!strncmp(userlist[i]->psaawd,passwd,strlen(userlist[i]->psaawd)-1))
		{
			ci->perm=userlist[i]->perm;
			strcpy(ci->name,userlist[i]->name);
			strcpy(ci->pwd,userlist[i]->pwd);
			printf("new_client %s\n",username);
		}
	}
}

void command_put(client_info * ci)//requre W
{	if(!ci->data_client_fd)
		ci->data_client_fd=accept(data_listenfd,NULL,NULL);

	if((ci->perm)%W!=0){
		send_ERR(ci,"reject:please login or check you privi\n");
		send_EOT(&(ci->buffer), ci->client_fd);
	return;
	}
	pathcat(ci,1);
	FILE* f = fopen(ci->buffer.data, "wb");
	ci->buffer.type = MSG;
	ci->buffer.comid = PUT;
	strcpy(ci->buffer.data, f ? "Transfering....." : "Server error!");
	if((send(ci->client_fd, &(ci->buffer), size_packet, 0)) != size_packet)
		err_exit("sned err");
	if(f)
	{
		receive_file(&(ci->buffer), ci->data_client_fd, f);
		fclose(f);
	}
}
void send_ERR(client_info* ci,char *msg){//send err(MSG) back to cli
	ci->buffer.type = MSG;
	strcpy(ci->buffer.data,msg);
		if((send(ci->client_fd, &(ci->buffer), size_packet, 0)) != size_packet)
		err_exit("sned err");
}




















void pathcat(client_info* ci,int type){//cat pwd with rela path
	// char t[200];
	if(type==0)//dir
	if(ci->buffer.data[strlen(ci->buffer.data)-1]!='/'){
		ci->buffer.data[strlen(ci->buffer.data)-1]='/';
		ci->buffer.data[strlen(ci->buffer.data)]='\0';
	}
	if(type==1)
		if(ci->buffer.data[strlen(ci->buffer.data)-1]=='\n'){
		ci->buffer.data[strlen(ci->buffer.data)-1]='\0';
		// ci->buffer.data[strlen(ci->buffer.data)]='\0';
	}
	strcpy((ci->buffer.data)+200,ci->buffer.data);
	strcpy(ci->buffer.data,ci->pwd);
	strcat(ci->buffer.data,(ci->buffer.data)+200);
	printf("%s\n",ci->buffer.data);
}


















int tcp_listen(const char *ip, const int port_number)
{
    struct sockaddr_in server_addr = {0};
    server_addr.sin_family = AF_INET;           /* ipv4 */
    server_addr.sin_port = htons(port_number);
    if(inet_pton(server_addr.sin_family, ip, &server_addr.sin_addr) == -1){
        err_exit("inet_pton");
    }
    int sockfd = socket(PF_INET, SOCK_STREAM, 0);
    if(sockfd == -1){
        err_exit("socket");
    }
    int reuse = 1;
    if(setsockopt(sockfd, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse)) == -1)
    {
        err_exit("setsockopt");
    }

    if(bind(sockfd, (struct sockaddr*)&server_addr, sizeof(server_addr)) == -1){
        err_exit("bind");
    }
    if(listen(sockfd, 5) == -1){
        err_exit("listen");
    }
    return sockfd;
}
client_info* new_client(int fd){//when  accept //new empty NIL priv user
	int i;
	client_info* ci=calloc(1,sizeof(client_info));
	ci->client_fd=fd;
	ci->perm=NIL;
	strcpy(ci->name,"Anonymous");
	return ci;
}

int load_user(char * file){//load users from file
	user* u;
	char *ptr;  
    char *p;  
    char str[200]; 
	if(file ==NULL)
		file="./config";
	FILE *f=fopen(file,"r");
	if(!f)
		err_exit("open config error");

	while (!feof(f)) 
     { 
         fgets(str,1024,f);  //读取一行 	 
    ptr = strtok_r(str, " \t\n", &p);   
		if(ptr!=NULL){
			u=malloc(sizeof(user));
			strcpy(u->name,ptr);
			userlist[user_num++]=u;
		}else err_exit("config error");
	ptr = strtok_r(NULL, " \t\n", &p);  
			if(ptr!=NULL){
			strcpy(u->psaawd,ptr);
		}else err_exit("config error");
	ptr = strtok_r(NULL, " \t\n", &p);  
			if(ptr!=NULL){
			u->perm=atoi(ptr);
		}else err_exit("config error");
	ptr = strtok_r(NULL, " \t\n", &p);  
			if(ptr!=NULL){
			strcpy(u->pwd,ptr);
		}else err_exit("config error");
		printf("LOAD:%s,%s\n",u->name,u->psaawd);
	 }
}

