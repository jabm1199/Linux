#include "commons.h"
#include "file_transfer_functions.h"

#define IPSERVER	"127.0.0.1"

#define LENUSERINPUT	1024
extern int fd_data;
extern int curr_to;
extern int my_id;
extern int fd_control;
int parse_command(struct packet*,char [LENUSERINPUT]);
int create_socket(const char *ip, const int port_number);
void command_bye(struct packet*,  int);
void command_send(struct packet*);
void command_leave(struct packet*);
void command_join(struct packet*);
void command_put(struct packet*,  int, char*);
void command_login(struct packet*,  int, char*);


