#ifndef COMMONS_H
#define COMMONS_H

// #define DEBUG

#ifndef CURR_VERSION
#define CURR_VERSION 1
#endif
#include <sys/epoll.h>
#include <sys/stat.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <errno.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <dirent.h>
#include <pthread.h>
#define	PORTSERVER	12345
#define CONTROLPORT	PORTSERVER
#define DATAPORT	(PORTSERVER + 1)
#define MAX_DIR 256
enum TYPE
	{
		COMMAND,
		MSG,
		TERM,
		DATA,
		EOT
	};
//err handleing
#define err_exit(m) (perror(m),exit(EXIT_FAILURE))

#define	LENBUFFER	480

typedef struct packet//all network commu socket
{
	u_int16_t ver;//version
	u_int16_t type;//enum type
	u_int16_t comid;//enum cmd
	u_int16_t to;
	u_int16_t from;
	char from_name[20];
	u_int16_t datalen;
	char data[LENBUFFER];
}ftp_pack;


int cali_pack(struct packet*);//reset byte order accordiing to CURR_VERSION



#define NCOMMANDS 7
enum CMD_ID
	{
		LOGIN,
		PUT,
		BYE,
		CHAT,
		SEND,
		JOIN,
		LEAVE
	};
#endif

