#include "commons.h"

static size_t size_packet = sizeof(struct packet);



int cali_pack(ftp_pack* pack)//same as encode if encyrpt then different 
{	
	if(ntohs(pack->ver)==CURR_VERSION){ //if ver ==CURR_V do nothing
		pack->ver=ntohs(pack->ver);
		pack->type=ntohs(pack->type);
		pack->comid=ntohs(pack->comid);
		pack->datalen=ntohs(pack->datalen);
		pack->to=ntohs(pack->to);
	}
	return 0;
}

