#include "server_ftp.h"

static socklen_t size_sockaddr = sizeof(struct sockaddr);
static size_t size_packet = sizeof(struct packet);

int epfd;//epoll fd
static int  nthreads=10;
uint64_t clifd[MAXNCLI];//
int iget,iput;

pthread_mutex_t     clifd_mutex = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t      clifd_cond = PTHREAD_COND_INITIALIZER;
Thread *tptr;//thread list
client_info *clilist[MAXNCLI]={0};
user **userlist;
group grouplist[50];

int user_num;
client_info *cli;
int listenfd,connfd,data_listenfd;

void* serve_client(void*);
void *thread_main(void *);
void thread_make(int);
int handle_request(client_info * ci);
void close_conn(client_info *ci);


int main(int argc,char**argv)
{
	//init daemon
#ifdef DEBUG
	deamon_init(argv[0],0);
#endif

	//init config
	user_num=0;//init 0
	userlist=calloc(MAX_USER,sizeof(user*));
	if(argc>1)
		load_user(argv[1]);//from default path
	else{
		printf("using default cfg\n");
		load_user(NULL);
	}
	

	//init tcp conn
	
	listenfd=tcp_listen("0.0.0.0",CONTROLPORT);//control
	data_listenfd=tcp_listen("0.0.0.0",DATAPORT);//file data

	//prealloc all thread
		int i;//loop
	if((tptr=calloc(nthreads,sizeof(Thread)))<0)err_exit("alloc thread list");
	iget=iput=0;
	for(i=0;i<nthreads;i++)
		thread_make(i);

	//init epoll
	struct epoll_event ev; //temp ev 
	struct epoll_event evlist[MAX_EVENTS]; //interested events	
	epfd=epoll_create(MAXNCLI);
	if(epfd==-1)
		err_exit("epoll_create");


	//add listenfd to epoll
	ev.data.fd=listenfd;
	ev.events=EPOLLIN;
	if(epoll_ctl(epfd, EPOLL_CTL_ADD, listenfd, &ev) == -1){
        err_exit("epoll_ctl");
    }

	//main loop
	for(;;)
	{
		int number = epoll_wait(epfd, evlist, MAX_EVENTS, -1);
			for (int i = 0; i < number; i++)
            {
                int eventfd = evlist[i].data.fd;
				//err msg or offband  emmm. idont know what todo so kill it
				if (evlist[i].events & (EPOLLERR | EPOLLHUP)) {
                		fprintf (stderr, "epoll get error from conn\n");
						epoll_ctl(epfd, EPOLL_CTL_DEL, eventfd, NULL);
                		close (evlist[i].data.fd);
                		continue;
            	}//new inbond connection
				else if(eventfd == listenfd&&(evlist[i].events & EPOLLIN)){
                    struct sockaddr_in client_addr;
                    socklen_t client_addr_len = sizeof(client_addr);
                    connfd = accept(listenfd, (struct sockaddr *)&client_addr, &client_addr_len);
						if (connfd == -1) {
							if (errno != EAGAIN && errno != ECONNABORTED
									&& errno != EPROTO && errno != EINTR)
							perror("accept");
							continue;							
						}
						// continue;
					printf("%s:%d connected.\n", inet_ntoa(client_addr.sin_addr), ntohs(client_addr.sin_port));
				//	setnoblock(connfd);//block is better .........emmm to deal with .fk
                    ev.data.fd = connfd;
					client_info *ci=new_client(connfd);//build new structure for each connection\
																	link it with fd in epoll\
																	make full use epoll\
																													excellent,neednt poll
					ev.data.u64=ci;//link here
                    ev.events = EPOLLIN|EPOLLET;//ET
                    if(epoll_ctl(epfd, EPOLL_CTL_ADD, connfd, &ev) == -1)//epoll add
                        err_exit("epoll_ctl2");

                }
				else if(evlist[i].events&EPOLLIN)//incoming data from clifd\
													waking a new thread to deal with it
				{
					pthread_mutex_lock(&clifd_mutex);
					clifd[iput] = evlist[i].data.u64;
					if (++iput == MAXNCLI)
						iput = 0;
					if (iput == iget)
						perror("iput=iget");
					pthread_cond_signal(&clifd_cond);
					pthread_mutex_unlock(&clifd_mutex);

                }
			}
	}	
	return 0;
}




void close_conn(client_info *ci){//close fd epoll ci
	if(epoll_ctl(epfd, EPOLL_CTL_DEL, ci->client_fd, NULL) == -1){
		perror("epoll del");
	}
	close(ci->client_fd);;
	free(ci);
}

int handle_request(client_info * ci)
{
	int r;
	int clientfd;
	clientfd=ci->client_fd;
	while ((r=read(clientfd, &(ci->buffer), size_packet)) <= 0)
	{
		if(r<0&&(errno==EAGAIN)){
		fprintf(stderr, "again\n");
		continue;
		}
		else
		{
		perror("recv");
		fprintf(stderr, "client closed/terminated. closing connection.\n");
		close_conn(ci);
		return 1;
		}	
	}
	
	cali_pack(&(ci->buffer));

	if(ci->buffer.type == TERM)
		return 1;
	
	else if(ci->buffer.type == COMMAND)
	{
		switch(ci->buffer.comid)
		{
			case LOGIN:
				command_login(ci);
				break;
			case PUT:
				command_put(ci);
				break;
			case SEND:
				command_send(ci);
				break;
			case JOIN:
				command_join(ci);
				break;
			case LEAVE:
				command_leave(ci);
				break;
			case BYE:
				close_conn(ci);
				break;
			default:
				break;
		}
	}
	else
	{
		fprintf(stderr, "packet incomprihensible. closing connection.\n");
		return;
	}
}


void thread_make(int i)
{
	void	*thread_main(void *);
	pthread_create(&tptr[i].tid, NULL, &thread_main, (void *) i);
	return;		/* main thread returns */
}

void *
thread_main(void *arg)
{
	client_info *ci;
	int i;

	for ( ; ; ) {
		//mutex
    	pthread_mutex_lock(&clifd_mutex);
		while (iget == iput)
			pthread_cond_wait(&clifd_cond, &clifd_mutex);
		ci =((client_info*)(clifd[iget]));	/* get connected client from epoll data */
		if (++iget == MAXNCLI)
			iget = 0;
		pthread_mutex_unlock(&clifd_mutex);
		tptr[(int) arg].thread_count++;
		//mutex
		printf("handling %s\n",ci->name);
		handle_request(ci);
	}
}