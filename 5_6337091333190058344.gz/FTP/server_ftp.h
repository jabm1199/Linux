#include "commons.h"
#include "file_transfer_functions.h"

#include <time.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <signal.h>
#include <syslog.h>
#define MAX_EVENTS     32
#define MAX_USER 32
#define MAXFD 64//for close on runing
extern int data_listenfd;

enum perm{//user priv
	NIL=5,//none
	W=2,//write
	R=3,//read
	RW=6//read and write
};


//thread pool
typedef struct{
	pthread_t tid;//threadtid
	long thread_count;//working connections//not used keep it is fine
}Thread;


typedef struct{
	int id;
	int fd_list[50];
}group;
extern group grouplist[50];

#define MAXNCLI 32
typedef struct {
	char name[10];
	char psaawd[MAX_DIR];
	char pwd[10];
	int perm;
}user;

typedef struct 
{
	char wd[MAX_DIR];//user dir
	char pwd[MAX_DIR];//present user dir not password
	char name[10];
	int perm;
	int client_fd;
	ftp_pack buffer;
	int data_client_fd;//data file 
}client_info;


extern user **userlist;//users read from config
extern int user_num;//....


int tcp_listen(const char *ip, const int port_number);
void close_conn(client_info *ci);
// int deamon_init(const char *pname, int facility);
int load_user(char * file);


void mod_client(client_info *ci,char *username,char* passwd);
client_info* new_client(int);

void command_login(client_info *);
void command_put(client_info *);

void command_send(client_info *);
void command_join(client_info* ci);
void command_leave(client_info* ci);