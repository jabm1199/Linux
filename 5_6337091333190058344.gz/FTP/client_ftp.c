#include "client_ftp.h"
int fd_control,fd_data;
int curr_to;
int my_id;
int main(int argc, char* argv[])
{
	fd_data=0;
	size_t size_packet = sizeof(ftp_pack);
	ftp_pack* pack = (ftp_pack*) malloc(size_packet);		//  packet
	bzero(pack,sizeof(ftp_pack));
	fd_control=create_socket(IPSERVER , PORTSERVER);	
	printf("%s:%d...\n", IPSERVER, PORTSERVER);
	char lpwd[LENBUFFER];
	char userinput[LENUSERINPUT];

	for(;;)
	{
		printf("\nCLIENT> ");
		fgets(userinput, LENUSERINPUT, stdin);	
		if(parse_command(pack,userinput)){
			fprintf(stderr, "err parsing\n");
			continue;
			}
		switch(pack->comid)
		{
			case LOGIN:
				if(pack->data[0])
					command_login(pack,  fd_control,pack->data);
				else
					fprintf(stderr, "need username and passwd\n");
				break;
			case PUT:
				if(pack->data[0])
					command_put(pack,fd_control, pack->data);
				else
					fprintf(stderr, "PUT command requires \"path to file\".\n");
				break;
			case SEND:
				command_send(pack);	
				break;	
			case JOIN:
				command_join(pack);	
				break;	
			case LEAVE:
				command_leave(pack);	
				break;		
			case BYE:
				command_bye(pack, fd_control);
				break;
			default:
				break;
		}
	}

	close(fd_control);
	
	return 0;
}

