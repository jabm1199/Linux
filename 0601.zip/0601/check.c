#include "check.h"

int reg_check(struct message *recievemsg)
{
	int fd;
	int read_size,write_size;
	struct message cmpmsg;
	if(strlen(recievemsg->name)>10 || strlen(recievemsg->msg)>20 )
	{
		return 1;
	}
	
	if(strcmp(recievemsg->name,"all")==0)
	{
		return -1;
	}
	if(strcmp(recievemsg->name,"reg")==0)
	{
		return -1;
	}
	if(strcmp(recievemsg->name,"login")==0)
	{
		return -1;
	}
	if(strcmp(recievemsg->name,"trans")==0)
	{
		return -1;
	}
	if((fd=open("user.txt",O_RDWR|O_CREAT|O_APPEND,0666))<0)
	{
		perror("open");
		printf("open\n");
		return -2;
	}
	do
	{
		if((read_size=read(fd,&cmpmsg,sizeof(cmpmsg))) < 0)
		{
			perror("read");
			close(fd);
			return -2;
		}
		if(read_size != sizeof(struct message) && read_size !=0)
		{
			close(fd);
			return -2;
		}
	if(strcmp(recievemsg->name,cmpmsg.name)==0)
		{
			close(fd);
			return -1;
		}	
	}while(read_size == sizeof(struct message));
	if((write_size=write(fd,recievemsg,sizeof(struct message)))<0)
	{
		perror("write");
		close(fd);
		return -2;
	}
	while(write_size!=sizeof(struct message))
	{
		//write_size = 0-writesize;
		lseek(fd,-write_size,SEEK_CUR);
		write_size=write(fd,recievemsg,sizeof(struct message));
	}
	
	printf("write file success\n");
	close(fd);
	return 0;
}

int login_check(struct message *recievemsg)
{
	int fd;
	struct message cmpmsg;
	int read_size;
	if((fd=open("user.txt",O_RDONLY))<0)
	{
		perror("open");
		return -2;
	}
	
	do
	{
		if((read_size=read(fd,&cmpmsg,sizeof(struct message)))<0)
		{
			perror("read");
			close(fd);
			return -2;
		}
		
		if(read_size != sizeof(struct message) && read_size!=0)
		{
			close(fd);
			return -2;
		}
		
		if((strcmp(recievemsg->name,cmpmsg.name)==0)&&(strcmp(recievemsg->msg,cmpmsg.msg)==0))
		{
			close(fd);
			return 0;
		}
		
	}while(read_size>0);
	
	close(fd);
	return -1;
}
void main()
{
struct message sendmsg;
printf("input name:\n");
gets(sendmsg.name);
printf("input mima:\n");
gets(sendmsg.msg);
printf("%d\n",reg_check(&sendmsg));	
}
