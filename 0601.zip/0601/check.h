#include <fcntl.h>
#include <sys/stat.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <pthread.h>
#define MAXLEN 1024
struct message
{
	char flag[15];
	char name[10];
	int size;
	char msg[MAXLEN];
};
int reg_check(struct message *recievemsg);
int login_check(struct message *recievemsg);
