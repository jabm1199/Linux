#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <errno.h>
#include <netinet/in.h>
#include <pthread.h>
typedef struct _clientinf
{
	char name[10];
	struct sockaddr_in addr_in;
	int decr;
	pthread_t pid;
}clientinf;
typedef clientinf datatype;
typedef struct _LNode
{   datatype data;
	struct _LNode * next;
}LNode,*LinkList;
extern LinkList CreateLinkList(void);
extern void deletelist(LinkList L ,datatype e);
extern void insertend(LinkList L,datatype e);
extern  void DisplayList(LinkList L);
