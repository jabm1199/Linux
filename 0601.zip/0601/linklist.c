#include "linklist.h"

LinkList CreateLinkList()
{
	LinkList L = (LinkList)malloc(sizeof(LNode));
	L->next = NULL;
	return L;
}
void deletelist(LinkList L ,datatype e)
{
	int i=0;
	LinkList s,p;
	p = L;
	while ( (strcmp(p->data.name,e.name) != 0) && p->next != NULL)
	{
		s=p;
		p = p->next;
	}
	if (p->next == NULL &&   (strcmp(p->data.name,e.name) != 0))
	{
		return;
	}
	else
	{
		s->next = p->next;
		free(p);
	}
}
void insertend(LinkList L,datatype e)
{
	int i=0;
	LinkList s,p;
	p = L;
	while(p->next != NULL)
	{
		p = p->next;
		i++;
	}
	
	s = (LinkList)malloc(sizeof(LNode));
	s->data =e;
	s->next = p->next ;
	p->next =s;
	
}

void DisplayList(LinkList L)
{
	
	L=L->next;
	int i = 1;
	while (L != NULL)
	{
		printf("%d. %s   \n",i,L->data.name);
		L = L->next;
		i++;
	}
}

void main()
{
/*
LinkList L;
datatype res=0;
L=CreateLinkList();

  printf("aaaaa\n");
  DisplayList(L);
  
	printf("aaaaa\n");
	printf("\n");
	insertend(L,500);
	printf("\n");
	insertend(L,300);
	printf("\n");
	insertend(L,200);
	DisplayList(L);
	printf("\n");
	deletelist(L,200);
	DisplayList(L);
	printf("ɾ����2��λ�õ�%d��",res);
	printf("\n");
	
*/	  
}
