#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <errno.h>
#include <netinet/in.h>
#include <pthread.h>
#include <arpa/inet.h>
#include <signal.h>
#include "linklist.h"
#include "check.h"
#define MAXLEN 1024
LinkList clientlink;
void handlesignal()
{
	int choose;
	char name[10];
	while(1)
	{
        	printf("1.T��ָ���ͻ��ˣ�2.�رշ�����,3.��ʾ���߿ͻ���\n");
        	scanf("%d",&choose);
        	while(choose < 1 || choose > 3)
        	{	
			printf("������������ʾ��ѡ��:\n");
			scanf("%d",&choose);
        	}
        	gets(name);
        	if(choose == 1)
        	{
			printf("���������߳�ȥ�Ŀͻ�������:\n");
			gets(name);
			if(strcmp(name,"") == 0) continue;
			LinkList L,s;
			L = clientlink;
			L=L->next;
			s = L;
			while((strcmp(L->data.name,name) != 0) && L->next != NULL)
			{
				s = L;
				L = L->next;
			}
			//printf("1%s\n",L->data.name);
			if(L->next == NULL && (strcmp(L->data.name,name) != 0))
			{
				printf("�ÿͻ��˲�����\n");
				
			}
			else
			{
				close(L->data.decr);
				pthread_cancel(L->data.pid);
				s->next = L->next;
				free(L);
			}
			printf("3\n");
        	}
        	else if(choose == 2)
        	{
			return;
        	}
        	else if(choose == 3)
        	{
			DisplayList(clientlink);
			
        	}
	}
}
void handleclient (clientinf *client)
{
	clientinf clientNode = *client;
	int nread;
	struct message a;
	LinkList transfileNode;
	char buf[MAXLEN],str[MAXLEN];
	while(1)
	{
		nread= recv(clientNode.decr,&a,sizeof(a),0);
		if(nread == 0)
		{
			strcpy(a.flag,"sermsg");
			printf("�ͻ���%s�˳�\n",clientNode.name);
			deletelist(clientlink ,clientNode);
			LinkList L;
			L = clientlink;
			L=L->next;
			sprintf(buf,"�ͻ���%s�˳�\n",clientNode.name);
			while(L != NULL)
			{
				send(L->data.decr,buf,strlen(buf)+1,0);
				L = L->next;
			}
			return;
		}
		if(strcmp(a.flag,"login") == 0)
		{
			int i;
			i = login_check(&a);
			if(i == 0)
			{
				strcpy(buf,"��¼�ɹ�!");
				strcpy(clientNode.name,a.name);
				insertend(clientlink,clientNode);
				send(clientNode.decr,buf,strlen(buf)+1,0);
			}
			else
			{
				strcpy(buf,"��¼ʧ��!");
				send(clientNode.decr,buf,strlen(buf)+1,0);
			}
			continue;
		}
		else if(strcmp(a.flag,"reg") == 0)
		{
			int i;
			i = reg_check(&a);
			if(i == 0)
			{
				strcpy(buf,"ע��ɹ�!");
				strcpy(clientNode.name,a.name);
				send(clientNode.decr,buf,strlen(buf)+1,0);
			}
			continue;
		}
		else if (strcmp(a.flag,"all") == 0)
		{
			if (strcmp(a.msg,"") != 0)
			{
				LinkList L;
				L = clientlink;
				L=L->next;
				strcpy(a.name,clientNode.name);
				while(L != NULL)
				{
					send(L->data.decr,&a,sizeof(struct message),0);
					L = L->next;
				}
			}
			continue;
		}
		else if(strcmp(a.flag,"view") == 0)
		{
			LinkList L;
			int i = 1;
			L = clientlink;
			L=L->next;
			memset(buf,0,strlen(buf));
			while(L != NULL)
			{
				memset(str,0,strlen(str));
				sprintf(str,"%d. %s\n",i,L->data.name);
				strcat(buf,str);
				//      send(clientNode.decr,str,strlen(str)+1,0);
				L = L->next;
				i++;
			}
			strcpy(a.name,clientNode.name);
			strcpy(a.msg,buf);
			send(clientNode.decr,&a,sizeof(struct message),0);
			continue;
		}
		else if(strcmp(a.flag,"trans") == 0)
		{
			LinkList L;
			L = clientlink;
			L=L->next;
			while(L != NULL)
			{
			if (strcmp(L->data.name,a.name) == 0)
				{
					break;
				}
				L = L->next;
			}
			if(L == NULL)
			{
				strcpy(a.msg,"noexist");
				send(clientNode.decr,&a,sizeof(struct message),0);
			}
			else
			{
				transfileNode = L;
				strcpy(a.name,clientNode.name);
				send(L->data.decr,&a,sizeof(struct message),0);
				
			}
			continue;
		}
		else if(strcmp(a.flag,"transf") == 0)
		{	send(transfileNode->data.decr,&a,sizeof(struct message),0);
			continue;
		}
		else
		{
			LinkList L;
			L = clientlink;
			L=L->next;
			//sprintf(buf,"%s:%s\n",clientNode.name,a.msg);
			strcpy(a.name,clientNode.name);
			while(L != NULL)
			{
				if (strcmp(L->data.name,a.flag) == 0)
				{
					//send(L->data.decr,buf,strlen(buf)+1,0);
					send(L->data.decr,&a,sizeof(struct message),0);
					break;
				}
				L = L->next;
			}
			continue;
		}
        }
}
void handleaccept(int *serverfd)
{
	socklen_t client_len;
	int sockfd = *serverfd;
	clientinf clientNode;
	struct sockaddr_in client_addr;
	while(1)
	{
		client_len =sizeof(struct sockaddr_in);
		if((clientNode.decr = accept(sockfd,(struct sockaddr *)&client_addr,&client_len)) == -1)
		{
			printf("��������ʧ��\n");
		}
		else
		{
			printf("��%s:%d���ӽ����ɹ�\n",inet_ntoa(client_addr.sin_addr),ntohs(client_addr.sin_port));
			clientNode.addr_in = client_addr;
		pthread_create(&clientNode.pid,NULL,(void *)handleclient,(void *)&clientNode);
		}
	}
}
int main(int argc ,char *argv[])
{
	struct sockaddr_in server_addr,client_addr;
	int sockfd,connectfd,port,nread;
	pthread_t pid;
	char buf[MAXLEN];
	char str[MAXLEN];
	if(argc != 2)
	{
		printf("������˿�\n");
		exit(1);
	}
        if((sockfd= socket(AF_INET,SOCK_STREAM,0)) == -1)
        {
			printf("����socketʧ��\n");
			exit(1);
        }
        clientlink = CreateLinkList();
        clientlink->data.decr = sockfd;
        port = atoi(argv[1]);
        bzero(&server_addr,sizeof(struct sockaddr_in));
        server_addr.sin_family = AF_INET;
        server_addr.sin_addr.s_addr = htonl(INADDR_ANY);
        server_addr.sin_port = htons(port);
	if(bind(sockfd,(struct sockaddr *)&server_addr,sizeof(struct sockaddr)) == -1)
        {
			printf("�󶨶˿�ʧ��,�˿ڿ��ܱ�ռ��\n");
			exit(2);
	}
        if(listen(sockfd,20) == -1)
        {
			printf("�����˿�ʧ��\n");
			exit(3);
        }
		
        printf("���ڼ�����...\n");
        pthread_create(&pid,NULL,(void *)handleaccept,(void *)&sockfd);
        handlesignal();
        return 0;
	
}
