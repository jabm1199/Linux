#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <pthread.h>
#define NUM 32
#include "mymsg.h"


char me[12];
void *read_thread(void *p)
{
    int comm_sock = *(int *)p;
    msg mymsg;
    int msglen;
    msglen = sizeof(msg);
    while(1)
    {
        memset(&mymsg, '\0', msglen);
        read(comm_sock, &mymsg, msglen);
        switch(mymsg.command)
        {
        // 私聊选项-----
        case 2:
            // 文件传输
            if(mymsg.subtype == 11)
            {
                FILE *f = fopen(mymsg.mess, "wb");
                if(!f)
                {
                    fprintf(stderr, "文件无法打开--. Aborting...\n");
                    break;
                }
                printf("正在接收文件 %s 请稍后--\n", mymsg.mess);
                int i = 0, j = 0;
                for(;;)
                {
                    read(comm_sock, &mymsg, msglen);
                    if(mymsg.subtype == 12)
                    {
                        i += fwrite(mymsg.mess, 1, mymsg.messlen, f);
                        j++;
                        printf("接受了 %d\n", j * 127 + i);
                    }
                    else if(mymsg.subtype == 13)
                    {
                        fclose(f);
                        printf("文件传输结束\n");
                        break;

                    }
                    // else
                    // {
                    //     // printf("【私聊消息：】%s 发消息:%s\n", mymsg.me, mymsg.mess);
                    // }
                }
            }
            // 会话
            else if (mymsg.subtype == 21)
            {
                printf("【私聊消息：】%s 发消息:%s\n", mymsg.me, mymsg.mess);
                break;
            }
            break;

        // 群聊选项-----
        case 6:
            printf("【群聊消息：】%s 发消息:%s\n", mymsg.me, mymsg.mess);
            break;

        // 退出选项-----
        case 7:
            if(strcmp(mymsg.mess, "exit") == 0) 
            break;
        }

        if(strcmp(mymsg.mess, "exit") == 0) break;
    }
}

//login
void login(int comm_sock)
{
    int msglen;
    msg sendmsg;
    msglen = sizeof(msg);
    memset(&sendmsg, '\0', msglen);
    memset(me, '\0', 12);
    sendmsg.command = 1;
    strcpy(sendmsg.sendto, "login");
    sendmsg.sendtolen = strlen(sendmsg.sendto);
    strcpy(sendmsg.mess, "login");
    sendmsg.messlen = strlen(sendmsg.mess);
    printf("-------请取一个好听的名字--------\n");
    scanf("%s", me);
    strcpy(sendmsg.me, me);
    sendmsg.melen = strlen(sendmsg.me);
    write(comm_sock, &sendmsg, msglen);
}

int main()
{
    int t;
    char filename[256];
    struct sockaddr_in  ser_addr;
    int comm_sock;
    int len;
    char buffer[NUM];
    pthread_t tid;
    void *r;
    int msglen;
    msg sendmsg;
    comm_sock = socket(AF_INET, SOCK_STREAM, 0);
    ser_addr.sin_family = AF_INET;
    ser_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
    ser_addr.sin_port = 9765;
    len = sizeof(ser_addr);
    connect(comm_sock, (struct sockaddr *)&ser_addr, len);

    printf("\033[35m--------欢迎来到聊天室-------\n\033[0m");
    login(comm_sock);
    pthread_create(&tid, 0, read_thread, (void *)(&comm_sock));
    while(1)
    {
        printf("\033[36m----菜单----\n\033[0m");
        printf("---2-私聊---\n");
        printf("---5-加群---\n");
        printf("---6-群聊---\n");
        printf("---7-退出程序---\n");

        msglen = sizeof(msg);
        memset(&sendmsg, '\0', msglen);
        printf("请输入你的选择：\n");
        scanf("%d", &sendmsg.command);

        switch(sendmsg.command)
        {
        // 选项选择
        case 2:          // 私聊
            printf("--------私聊模式：------\n");
            printf("你想发给谁：");
            scanf("%s", sendmsg.sendto);
            sendmsg.sendtolen = strlen(sendmsg.sendto);

            //文件----------------------------------
            printf("你想发送的类型:\n\t--1.文件\n\t--2.消息\n");
            scanf("%d", &t);
            if(t == 1) //file
            {
                printf("请输入文件绝对路径:\n");
                scanf("%s", filename);
                FILE *f = fopen(filename, "rb");
                if(!f)
                {
                    fprintf(stderr, "File could not be opened for writing. Aborting...\n");
                    break;
                }
                printf("请输入给别人看的文件名:\n");
                scanf("%s", sendmsg.mess);
                sendmsg.messlen = strlen(sendmsg.mess);
                strcpy(sendmsg.me, me);
                sendmsg.melen = strlen(sendmsg.me);
                sendmsg.subtype = 11;
                write(comm_sock, &sendmsg, msglen);
                //
                int i = 0, j = 0;
                while(!feof(f))
                {
                    memset(sendmsg.mess, '\0', sizeof(char) * 128);
                    sendmsg.messlen = fread(sendmsg.mess, 1, 128 - 1, f);


                    sendmsg.subtype = 12; //content

                    //    pack->datalen = fread(pack->data, 1, LENBUFFER - 1, f);
                    i += sendmsg.messlen ;
                    // printf("%d")
                    // if((send(sfd, pack, size_packet, 0)) != size_packet)
                    //     err_exit("send err");
                    write(comm_sock, &sendmsg, msglen);
                    j++;
                    printf("sending...%d sent\n", j * 127 + i);
                }
                sendmsg.subtype = 13; //eof
                write(comm_sock, &sendmsg, msglen);
                printf("over\n");
                break;

            }
            //文件--------------------------------
            //
            //会话
            if (t == 2)
            {
                printf("你想发送的内容");
                scanf("%s", sendmsg.mess);
                sendmsg.messlen = strlen(sendmsg.mess);
                strcpy(sendmsg.me, me);
                sendmsg.subtype = 21; //eof
                sendmsg.melen = strlen(sendmsg.me);
                write(comm_sock, &sendmsg, msglen);
                break;
            }
            else
            {
                printf("不是上面的选项，请重新输入！\n");
                break;
            }

        case 5:
            printf("--------加群模式：------\n");
            strcpy(sendmsg.sendto, "addgroup");
            sendmsg.sendtolen = strlen(sendmsg.sendto);
            printf("加入群的名称：");
            scanf("%s", sendmsg.mess);
            sendmsg.messlen = strlen(sendmsg.mess);
            strcpy(sendmsg.me, me);
            sendmsg.melen = strlen(sendmsg.me);
            write(comm_sock, &sendmsg, msglen);
            break;
        case 6:
            printf("--------群聊模式：------\n");
            printf("你想发给那个群：");
            scanf("%s", sendmsg.sendto);
            sendmsg.sendtolen = strlen(sendmsg.sendto);
            printf("你想发送的内容");
            scanf("%s", sendmsg.mess);
            sendmsg.messlen = strlen(sendmsg.mess);
            strcpy(sendmsg.me, me);
            sendmsg.melen = strlen(sendmsg.me);
            write(comm_sock, &sendmsg, msglen);
            break;

        case 7:
            strcpy(sendmsg.mess, "exit");
            break;
        
        default:
            printf("输入的命令有误，请重新输入\n");
            break;
        }

        if(strcmp(sendmsg.mess, "exit") == 0)break;
    }
    pthread_join(tid, &r);
}






